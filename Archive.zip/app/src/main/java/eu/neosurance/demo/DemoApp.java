package eu.neosurance.demo;

import com.clickntap.tap.App;

public class DemoApp extends App {
}
