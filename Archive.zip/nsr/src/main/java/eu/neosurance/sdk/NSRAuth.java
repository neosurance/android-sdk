package eu.neosurance.sdk;

public interface NSRAuth {
    public void authorized(boolean authorized) throws Exception;
}
