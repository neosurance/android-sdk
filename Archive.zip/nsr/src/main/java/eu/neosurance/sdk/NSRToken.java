package eu.neosurance.sdk;

public interface NSRToken {

    public void token(String token) throws Exception;

}
